# Agent prompt — Phase 2 design (design only, no implementation)

> **v2, 2026-08-23.** Supersedes the earlier version. D11 and D12 are now confirmed, so the
> agent is told what to design rather than asked to surface options. Copy everything below the
> line into the agent.

---

You are helping design a capstone project: a fail-closed runtime containment monitor that
intercepts an LLM agent's tool calls and returns ALLOW / DENY / GATE before execution.

**Read these first, in this order, and treat them as authoritative over your own assumptions:**
`tasks/spec.md`, `tasks/plan.md`, `Decision Log.md`, `tasks/todo.md`, `qa-redteam-plan.md`.
Decisions D1–D13 are all confirmed. Do not re-litigate any of them. If you believe one is wrong,
say so and stop — do not design around it silently.

**Your task this session is design, not implementation.** Produce documents and interface
definitions. Write no functional code beyond type signatures, dataclasses, enums, and
docstrings. I want to review the shape before anything is built.

## Deliverables

1. **`docs/design/architecture.md`** — module responsibilities and the boundaries between them,
   covering: verdict engine, policy loader, sequence engine, approval gate, audit writer,
   transport/dispatch, agent loop, mock tools. For each module state what it owns, what it may
   import, and what it must never import.

2. **`src/` interface skeleton** — signatures and types only, `NotImplementedError` bodies.
   The verdict function is pure and fail-closed:
   `evaluate(call: ToolCall, policy: Policy, state: SequenceState) -> Decision`.
   `Decision` is frozen and always carries a non-null `rule_id`.

3. **`docs/design/sequence-engine.md`** — the design of the kill-chain automaton (D1): states,
   transitions, what advances state, what emits DENY vs GATE. Use the canonical chain
   `get_balance → list_payees → add_payee → transfer_funds` as the worked example, where every
   call passes per-call checks and only the composition is blocked.

4. **Two Mermaid diagrams**, source committed under `docs/diagrams/`:
   - Sequence state machine (this is the hero diagram for the report and poster)
   - Data flow for a single tool call, including the audit-log write

5. **`docs/design/residual-risks.md`** — see the last section below.

## Hard constraints — these are not negotiable and violating one invalidates the design

- **Fail-closed.** No matching rule means DENY. The default is denial, never allow.
- **The agent's output can never influence a verdict.** Not its reasoning, not an argument
  named `approved`, not a persuasive `reason` string. The verdict is a function of the call and
  the policy only.
- **No LLM anywhere in the enforcement or scoring path.** Policy is human-authored declarative
  YAML. Escape scoring is a deterministic per-scenario checker.
- **Complete mediation.** A malformed or unknown tool call must still yield a `Decision` — never
  an exception that crashes open, never a passthrough.
- **Every decision is auditable** — append-only JSONL, traceable `rule_id`, argument hashed
  rather than logged in plaintext.
- Python 3.11, full type hints, dataclasses for value types, small pure functions for anything
  a verdict depends on.

## D11 — process boundary (confirmed)

The monitor runs as its own process. It owns the policy, the sequence state and the tool
implementations, and exposes a decision-and-dispatch endpoint on loopback.

**The agent never calls a tool.** It *proposes* a call; the monitor executes it if the verdict
permits, and returns the result. Design this as the primary path, not as a wrapper over direct
invocation.

Design `src/transport/` with two implementations behind one interface — in-process and loopback
— so the in-process form stays available as a documented scope cut. Under both,
**`src/agent` must have no import path to `src/tools` or `src/policy`**, and there must be a
test proving it (an import-graph assertion). That test is the evidence for the tamper-resistance
claim, so treat it as a deliverable rather than an afterthought.

## D12 — sequence-state retention (confirmed)

1. State is keyed on a **composite of monitor-assigned session id and resource principal** (the
   account, endpoint or client the chain acts against).
2. **The monitor assigns session identity.** The agent cannot supply, choose or rotate it.
3. **Nothing the agent does resets state** — no tool call, no argument, no declaration that a
   new task has begun. State clears only on monitor-side session end or idle expiry (default 30
   minutes, configurable, logged when it fires).
4. **Cross-session progress is reconstructed by replaying the audit log** over a configurable
   lookback window (default 24 hours). There is no second datastore. Chain-progress events are
   first-class audit records, and replay must reconstruct sequence state, not only decisions.
5. **Per-subject chain caps**, evicting least-advanced-first, with **every eviction written to
   the audit log as its own event**. Eviction must never be silent.

If any part of this is unimplementable as stated, stop and say so rather than substituting your
own retention policy.

## Residual risks to document

`docs/design/residual-risks.md` records what these decisions leave open, with the design
consequence of each:

- A chain paced slower than the 24-hour lookback window
- Novel orderings the automaton has not been taught (inherent to a bounded automaton —
  Schneider 2000)
- Eviction pressure from an attacker controlling many subjects
- Audit-log replay cost as the log grows, and what rotation plus snapshotting would require

## Working agreement

Ask before adding a dependency, changing the policy YAML schema, or changing a metric
definition. If a document contradicts another document, stop and tell me rather than choosing.
If something in the design feels forced, say so plainly — a weakness named now is cheaper than
one found in review.

When finished, give me a short summary of what you produced and the three design choices you
are least confident about.
