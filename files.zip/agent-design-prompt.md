# Agent prompt — Phase 2 design (design only, no implementation)

> Copy everything below the line into the agent. Assumes it can read the project files.
> Written to be safe while **D11** (process boundary) and **D12** (state retention) are still
> open — it forces both to be surfaced as choices rather than silently decided in code.

---

You are helping design a capstone project: a fail-closed runtime containment monitor that
intercepts an LLM agent's tool calls and returns ALLOW / DENY / GATE before execution.

**Read these first, in this order, and treat them as authoritative over your own assumptions:**
`tasks/spec.md`, `tasks/plan.md`, `Decision Log.md`, `tasks/todo.md`, `qa-redteam-plan.md`.
Decisions D1–D12 have already been made or deliberately deferred. Do not re-litigate a
Confirmed decision. Do not resolve an Open one on your own.

**Your task this session is design, not implementation.** Produce documents and interface
definitions. Write no functional code beyond type signatures, dataclasses, enums, and
docstrings. I want to review the shape before anything is built.

## Deliverables

1. **`docs/design/architecture.md`** — module responsibilities and the boundaries between them,
   covering: verdict engine, policy loader, sequence engine, approval gate, audit writer,
   mediated dispatch, agent loop, mock tools. For each module state what it owns, what it may
   import, and what it must never import.

2. **`src/` interface skeleton** — signatures and types only, `NotImplementedError` bodies.
   The verdict function is pure and fail-closed:
   `evaluate(call: ToolCall, policy: Policy, state: SequenceState) -> Decision`.
   `Decision` is frozen and always carries a non-null `rule_id`.

3. **`docs/design/sequence-engine.md`** — the design of the kill-chain automaton (D1): states,
   transitions, what advances state, what emits DENY vs GATE. Use the canonical chain
   `get_balance → list_payees → add_payee → transfer_funds` as the worked example, where every
   call passes per-call checks and only the composition is blocked.

4. **Two Mermaid diagrams**, source committed under `docs/diagrams/`:
   - Sequence state machine (this is the hero diagram for the report and poster)
   - Data flow for a single tool call, including the audit-log write

5. **`docs/design/open-questions.md`** — see the two open decisions below.

## Hard constraints — these are not negotiable and violating one invalidates the design

- **Fail-closed.** No matching rule means DENY. The default is denial, never allow.
- **The agent's output can never influence a verdict.** Not its reasoning, not an argument
  named `approved`, not a persuasive `reason` string. The verdict is a function of the call and
  the policy only.
- **No LLM anywhere in the enforcement or scoring path.** Policy is human-authored declarative
  YAML. Escape scoring is a deterministic per-scenario checker.
- **Complete mediation.** No code path reaches a tool without producing a `Decision` first. A
  malformed or unknown tool call must still yield a `Decision` — never an exception that
  crashes open, never a passthrough.
- **Every decision is auditable** — append-only JSONL, traceable `rule_id`, argument hashed
  rather than logged in plaintext.
- Python 3.11, full type hints, dataclasses for value types, small pure functions for anything
  a verdict depends on.

## Two decisions are OPEN — surface them, do not resolve them

**D11 — where the monitor runs.** The intended arrangement is a separate process with the
policy engine as the only path to the tools, so the agent has no reach into the policy object
or the tool functions. This is not yet confirmed. **Design so that the transport is swappable:**
dispatch goes through one interface with an in-process implementation and an IPC implementation
behind it, and the agent package has no import path to the tools package under either. Note in
`architecture.md` which security property depends on the boundary being real, and what has to
be disclosed if it degrades to in-process.

**D12 — how much state the monitor keeps.** Do not pick a retention policy. In
`open-questions.md`, lay out the options and their trade-offs for: what sequence state is keyed
to (session, task, operator, target account), how long it lives, whether anything the agent does
can reset it, whether it persists across runs, and what bounds its growth. For each option say
which evasion it defeats — interleaving, reordering, session reset, cross-session smear — and
what it costs in false blocks. I will decide from that document.

## Working agreement

Ask before adding a dependency, changing the policy YAML schema, or changing a metric
definition. If a document contradicts another document, stop and tell me rather than choosing.
If something in the design feels forced, say so plainly — a weakness named now is cheaper than
one found in review.

When finished, give me a short summary of what you produced and the three design choices you
are least confident about.
